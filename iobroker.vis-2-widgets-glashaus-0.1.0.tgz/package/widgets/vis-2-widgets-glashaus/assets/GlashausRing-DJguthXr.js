import{a as e,i as t}from"./_virtual_mf___mfe_internal__vis2GlashausWidgets__mf_owner__242410349350261__loadShare__shared-ClGxilUM.js";import{d as n,i as r,n as i,o as a,p as o,r as s,s as c,v as l,y as u}from"./GlashausWidget-DiYgujWi.js";import{a as d,n as f,r as p}from"./components-DBvWi8ZV.js";var m=78,h=`
.gh.gh-rg{padding:0;container:gh-rg/size}
.gh-rg-box{flex:1;min-height:0;display:flex;flex-direction:column;padding:20px}
.gh-rg .gh-h{margin-bottom:10px;flex-wrap:nowrap}
.gh-rg-t{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.gh-rg-body{flex:1;min-height:0;display:flex;flex-direction:column;align-items:center;gap:8px}
.gh-rg-wrap{flex:1;min-height:0;width:100%;container-type:size;display:grid;place-items:center}
.gh-rg-wrap>.gh-ring{--gh-sz:var(--gh-rg-rs)!important}
.gh-rg-in{display:flex;flex-direction:column;align-items:center;justify-content:center;max-width:78%;line-height:1}
.gh-rg-v{font-size:calc(var(--gh-rg-rs) * var(--gh-rg-f, .25));white-space:nowrap}
.gh-rg-v .gh-unit{font-size:.46em;margin-left:.12em}
.gh-rg-l{margin-top:calc(var(--gh-rg-rs) * .04);font-size:max(10px,calc(var(--gh-rg-rs) * .075));color:var(--gh-fg-2);
  max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:0}
.gh-rg-sub{flex:none;max-width:100%;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
  font-variant-numeric:tabular-nums}
.gh-rg-nodata .gh-rg-v{color:var(--gh-fg-3)}
@container (max-width:100px) or (max-height:100px){.gh-rg-l{display:none}}
@container gh-rg (max-width:170px) or (max-height:170px){
  .gh-rg-box{padding:12px}
  .gh-rg .gh-h{margin-bottom:6px}
  .gh-rg .gh-ico{width:26px;height:26px;border-radius:8px}
  .gh-rg .gh-ico svg{width:15px;height:15px}
  .gh-rg .gh-title{font-size:13.5px;gap:8px}
  .gh-rg-body{gap:4px}
  .gh-rg-sub{font-size:11.5px}
}
@container gh-rg (min-aspect-ratio:9/5) and (min-width:260px){
  .gh-rg-body.gh-rg-hassub{flex-direction:row;align-items:stretch;gap:18px}
  .gh-rg-hassub .gh-rg-wrap{flex:0 0 46%;width:auto;height:100%}
  .gh-rg-hassub .gh-rg-sub{flex:1;align-self:center;text-align:left;white-space:normal;font-size:14px;
    display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical}
}
@container gh-rg (min-width:320px) and (min-height:320px){
  .gh-rg-box{padding:24px}
  .gh-rg-sub{font-size:14px}
}
`,g=class g extends s{constructor(e){super(e),u(`ring`,h)}static getWidgetInfo(){return{id:`tplGlashausRing`,visSet:i,visSetLabel:`vis_2_widgets_glashaus`,visSetColor:r,visSetIcon:`widgets/${i}/img/vis-2-widgets-glashaus.svg`,visName:`Ring`,visWidgetLabel:`ring_widget`,visAttrs:[{name:`common`,fields:[{name:`oid`,label:`oid`,type:`id`,onChange:async(e,t,n,r)=>{let i=t[e.name];if(!a(i))return;let o=await r.getObject(i),c=o==null?void 0:o.common;if(!c)return;let u=!1;if(!t.title){let e=c.name;t.title=typeof e==`object`?e[s.getLanguage()]||e.en:e||i.split(`.`).pop(),u=!0}c.unit&&(!t.unit||t.unit===`%`)&&c.unit!==t.unit&&(t.unit=c.unit,u=!0),(l(t.min)??0)===0&&(l(t.max)??100)===100&&typeof c.min==`number`&&typeof c.max==`number`&&c.max>c.min&&(t.min=c.min,t.max=c.max,u=!0),u&&n(t)}},{name:`title`,label:`title`},{name:`showTitle`,label:`ring_show_title`,type:`checkbox`,default:!0},...s.iconFields(`batt`),...s.accentFields(``,`batt`),{name:`min`,label:`ring_min`,type:`number`,default:0},{name:`max`,label:`ring_max`,type:`number`,default:100},{name:`unit`,label:`unit`,default:`%`},{name:`decimals`,label:`decimals`,type:`number`,min:0,max:4,default:0},{name:`label`,label:`ring_label`,tooltip:`ring_label_tip`},{name:`sub`,label:`ring_sub`,tooltip:`ring_sub_tip`},{name:`thickness`,label:`ring_thickness`,type:`slider`,min:2,max:20,step:1,default:7},{name:`ringSize`,label:`ring_size`,type:`number`,min:0,max:1e3,default:0,tooltip:`ring_size_tip`}]},{name:`limits`,label:`group_ring_limits`,fields:[{name:`ringLimitsHelp`,type:`help`,text:`${i}_ring_limits_help`},{name:`critBelow`,label:`ring_crit_below`,type:`number`},{name:`warnBelow`,label:`ring_warn_below`,type:`number`},{name:`warnAbove`,label:`ring_warn_above`,type:`number`},{name:`critAbove`,label:`ring_crit_above`,type:`number`}]},s.designGroup()],visDefaultStyle:{width:220,height:240,position:`absolute`},visPrev:`widgets/${i}/img/prev_ring.png`}}getWidgetInfo(){return g.getWidgetInfo()}status(e){if(e===null)return`idle`;let t=this.state.rxData,n=l(t.critAbove),r=l(t.critBelow),i=l(t.warnAbove),a=l(t.warnBelow);return n!==null&&e>n||r!==null&&e<r?`crit`:i!==null&&e>i||a!==null&&e<a?`warn`:`ok`}renderWidgetBody(r){this.ghRenderStart(r);let i=this.state.rxData,u=this.ghLang(),h=!a(i.oid),g=this.ghNum(i.oid,m),_=l(i.min)??0,v=l(i.max)??100;v===_&&(v=_+1),v<_&&([_,v]=[v,_]);let y=g===null?null:(g-_)/(v-_),b=n(Math.round(l(i.decimals)??0),0,4),x=i.unit??``,S=this.status(g),C=this.ghAccent(``,`batt`),w=S===`crit`?`var(--gh-crit)`:S===`warn`?`var(--gh-warn)`:C,T=i.title||(h?s.tr(`ring_demo_title`):``),E=i.label||(h?s.tr(`ring_demo_label`):``),D=i.sub||(h?s.tr(`ring_demo_sub`):``),O=c(i.showTitle,!0)&&!!T,k=n(l(i.thickness)??7,1,24),A=l(i.ringSize)||0,j=A>0?`min(${A}px, 100cqw, 100cqh)`:`min(100cqw, 100cqh)`,M=o(g,b,u),N=M.length*.6+x.length*.3+.25,P=Math.min(.27,(.72-k*.006)/Math.max(1,N)),F=`${T?`${T}: `:``}${M}${x?` ${x}`:``}${E?`, ${E}`:``}`;return e(`div`,{className:this.ghClass(`gh-rg${g===null?` gh-rg-nodata`:``}`),children:[e(`div`,{className:`gh-rg-box`,children:[O?t(`div`,{className:`gh-h`,children:e(`h2`,{className:`gh-title`,children:[t(f,{name:this.ghIcon(),color:w}),t(`span`,{className:`gh-rg-t`,children:T})]})}):null,e(`div`,{className:`gh-rg-body${D?` gh-rg-hassub`:``}`,children:[t(`div`,{className:`gh-rg-wrap`,role:`img`,"aria-label":F,style:{"--gh-rg-rs":j,"--gh-rg-f":P.toFixed(3)},children:t(d,{value:y,stroke:k,color:w,children:e(`div`,{className:`gh-rg-in`,children:[e(`div`,{className:`gh-num gh-rg-v`,children:[t(p,{value:g,dec:b,lang:u}),x?t(`span`,{className:`gh-unit`,children:x}):null]}),E&&!(A>0&&A<100)?t(`div`,{className:`gh-rg-l`,children:E}):null]})})}),D?t(`div`,{className:`gh-rg-sub gh-muted gh-small`,children:D}):null]})]}),this.ghDemoBadge(h)]})}};export{g as default};