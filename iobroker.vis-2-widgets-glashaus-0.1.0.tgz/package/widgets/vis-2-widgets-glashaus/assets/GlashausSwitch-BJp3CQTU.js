import{a as e,c as t,i as n}from"./_virtual_mf___mfe_internal__vis2GlashausWidgets__mf_owner__242410349350261__loadShare__shared-ClGxilUM.js";import{_ as r,c as i,d as a,i as o,n as s,o as c,p as l,r as u,s as d,v as f,y as p}from"./GlashausWidget-DiYgujWi.js";import{n as m,t as h}from"./components-DBvWi8ZV.js";var g=`
.gh.gh-sw{padding:0;container:gh-sw/size;user-select:none;-webkit-user-select:none;
  transition:background .45s var(--gh-ease),color .45s,transform .5s var(--gh-spring)}
/* press feedback only for the tile itself, not while the dimmer is dragged */
.gh.gh-sw.gh-sw-live:has(> .gh-sw-hit:active){transform:scale(.97)}
.gh.gh-sw.gh-on.gh-glass:hover::after{opacity:.22}
.gh-sw-hit{flex:1;min-height:0;display:grid;gap:10px 12px;padding:16px;cursor:pointer;border-radius:inherit;outline-offset:-4px;
  grid-template-columns:minmax(0,1fr) auto;grid-template-rows:auto minmax(0,1fr);grid-template-areas:"ico tog" "txt txt"}
.gh-sw-edit .gh-sw-hit{cursor:default}
.gh-sw-hit:focus-visible{outline:2px solid currentColor}
.gh-sw-ico{grid-area:ico;display:flex;min-width:0}
.gh-sw-tg{grid-area:tog;display:flex;align-items:center}
.gh-sw-txt{grid-area:txt;align-self:end;min-width:0;display:flex;flex-direction:column}
.gh-sw-nm{font-weight:550;font-size:14.5px;line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.gh-sw-st{font-size:13px;color:var(--gh-fg-2);margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
  font-variant-numeric:tabular-nums;transition:color .45s}
.gh-sw-nodata .gh-sw-st{color:var(--gh-fg-3)}
.gh-sw-nodata .gh-ico{opacity:.55}
.gh-sw .gh-ico{transition:background .45s,color .45s,box-shadow .45s}
.gh.gh-sw.gh-on .gh-ico{background:var(--gh-c);color:var(--gh-bg);
  box-shadow:0 0 0 6px color-mix(in srgb,var(--gh-c) 24%,transparent),0 8px 26px -4px var(--gh-c)}
/* accent "ink" on an ink tile: the accent becomes the paper color */
.gh.gh-sw.gh-sw-ink.gh-on .gh-ico{color:var(--gh-fg)}
.gh.gh-sw.gh-sw-ink.gh-on .gh-toggle::after,.gh.gh-sw.gh-sw-ink.gh-on .gh-sw-fill::after{background:var(--gh-fg)}
.gh.gh-sw.gh-sw-spin.gh-on .gh-ico svg{animation:gh-sw-spin 1.4s linear infinite}
@keyframes gh-sw-spin{to{transform:rotate(360deg)}}
.gh-sw .gh-toggle{pointer-events:none}
.gh-sw .gh-toggle.gh-sw-tog-on{background:var(--gh-c,var(--gh-ok))}
.gh-sw .gh-toggle.gh-sw-tog-on::after{transform:translateX(18px)}
.gh-sw.gh-on .gh-toggle:not(.gh-sw-tog-on){background:color-mix(in srgb,var(--gh-bg) 22%,transparent)}
.gh-sw-go{display:grid;place-items:center;width:30px;height:30px;border-radius:50%;
  border:1px solid color-mix(in srgb,currentColor 24%,transparent);color:var(--gh-fg-2)}
.gh-sw-go svg{width:14px;height:14px}
.gh-sw-row .gh-sw-hit{grid-template-columns:auto minmax(0,1fr) auto;grid-template-rows:minmax(0,1fr);
  grid-template-areas:"ico txt tog";align-items:center;padding:12px 16px}
.gh-sw-row .gh-sw-txt{align-self:center}
.gh-sw-lvl{display:flex;align-items:center;gap:10px;padding:0 16px 14px;flex:none}
.gh-sw-trk{--gh-sw-k:26px;position:relative;flex:1;min-width:0;height:var(--gh-sw-k);border-radius:99px;cursor:pointer;touch-action:none;
  background:var(--gh-track);box-shadow:inset 0 1px 2px var(--gh-edge);outline-offset:3px}
.gh-sw-edit .gh-sw-trk{cursor:default}
.gh-sw.gh-on .gh-sw-trk{background:color-mix(in srgb,var(--gh-bg) 18%,transparent)}
.gh-sw-fill{position:absolute;left:0;top:0;bottom:0;min-width:var(--gh-sw-k);border-radius:99px;
  background:linear-gradient(90deg,color-mix(in srgb,var(--gh-c) 70%,transparent),var(--gh-c));
  transition:width .35s var(--gh-ease)}
.gh-sw-drag .gh-sw-fill{transition:none}
.gh-sw-fill::after{content:'';position:absolute;right:4px;top:4px;width:calc(var(--gh-sw-k) - 8px);height:calc(var(--gh-sw-k) - 8px);border-radius:50%;
  background:var(--gh-knob);box-shadow:0 1px 3px rgba(0,0,0,.25)}
.gh-sw-lv{font-size:13px;font-weight:550;font-variant-numeric:tabular-nums;min-width:44px;text-align:right;white-space:nowrap}
.gh-sw-cf{position:absolute;inset:0;z-index:3;border-radius:inherit;display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:12px;padding:12px;text-align:center;color:var(--gh-fg);
  background:color-mix(in srgb,var(--gh-bg) 96%,transparent);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);
  animation:gh-sw-in .3s var(--gh-ease) both}
@keyframes gh-sw-in{from{opacity:0;transform:scale(.96)}}
.gh-sw-q{font-size:14px;font-weight:550;line-height:1.25;max-width:100%;overflow:hidden;display:-webkit-box;
  -webkit-line-clamp:3;-webkit-box-orient:vertical}
.gh-sw-btns{display:flex;gap:8px;flex-wrap:wrap;justify-content:center}
.gh-sw-btns .gh-ink,.gh-sw-btns .gh-outline{height:34px;padding:0 14px;font-size:13px}
@container gh-sw (max-height:112px){
  .gh-sw-tile .gh-sw-hit{padding:11px 12px;gap:6px 10px}
  .gh-sw-tile .gh-ico{width:28px;height:28px;border-radius:9px}
  .gh-sw-tile .gh-ico svg{width:16px;height:16px}
  .gh-sw-nm{font-size:13.5px}
  .gh-sw-st{font-size:12px;margin-top:1px}
  .gh-sw-lvl{padding:0 12px 10px}
  .gh-sw-trk{--gh-sw-k:22px}
}
@container gh-sw (max-width:132px){
  .gh-sw-tile .gh-sw-hit{padding:12px}
  .gh-sw-lvl{padding:0 12px 12px}
  .gh-sw-lv{display:none}
}
/* too low for icon above text: one row like the "row" layout */
@container gh-sw (max-height:90px){
  .gh-sw-tile .gh-sw-hit{grid-template-columns:auto minmax(0,1fr) auto;grid-template-rows:minmax(0,1fr);
    grid-template-areas:"ico txt tog";align-items:center}
  .gh-sw-tile .gh-sw-txt{align-self:center}
}
@container gh-sw (max-height:122px){
  .gh-sw-tile.gh-sw-haslvl .gh-sw-hit{grid-template-columns:auto minmax(0,1fr) auto;grid-template-rows:minmax(0,1fr);
    grid-template-areas:"ico txt tog";align-items:center}
  .gh-sw-tile.gh-sw-haslvl .gh-sw-txt{align-self:center}
}
/* narrow rows: the ink tile shows the state, the toggle makes room for the text */
@container gh-sw (max-width:170px){
  .gh-sw-row .gh-sw-tg{display:none}
  .gh-sw-row .gh-sw-hit{grid-template-columns:auto minmax(0,1fr);grid-template-areas:"ico txt"}
}
@container gh-sw (max-width:170px) and (max-height:90px){
  .gh-sw-tile .gh-sw-tg{display:none}
  .gh-sw-tile .gh-sw-hit{grid-template-columns:auto minmax(0,1fr);grid-template-areas:"ico txt"}
}
@container gh-sw (max-width:170px) and (max-height:122px){
  .gh-sw-tile.gh-sw-haslvl .gh-sw-tg{display:none}
  .gh-sw-tile.gh-sw-haslvl .gh-sw-hit{grid-template-columns:auto minmax(0,1fr);grid-template-areas:"ico txt"}
}
@container gh-sw (min-width:250px) and (min-height:210px){
  .gh-sw-tile .gh-sw-hit{padding:20px}
  .gh-sw-tile .gh-ico{width:44px;height:44px;border-radius:14px}
  .gh-sw-tile .gh-ico svg{width:23px;height:23px}
  .gh-sw-tile .gh-sw-nm{font-size:18px}
  .gh-sw-tile .gh-sw-st{font-size:14px}
  .gh-sw-tile .gh-sw-lvl{padding:0 20px 20px}
  .gh-sw-tile .gh-sw-trk{--gh-sw-k:32px}
}
.gh-sw-cx-i{display:none}
@container gh-sw (max-height:130px){
  .gh-sw-cf{gap:6px;padding:8px}
  .gh-sw-q{-webkit-line-clamp:2;font-size:12.5px}
  .gh-sw-btns .gh-ink,.gh-sw-btns .gh-outline{height:28px;padding:0 10px;font-size:12px}
}
@container gh-sw (max-width:170px){
  .gh-sw-btns{gap:6px}
  .gh-sw-btns .gh-outline{width:28px;padding:0;justify-content:center}
  .gh-sw-cx-t{display:none}
  .gh-sw-cx-i{display:inline;font-size:15px;line-height:1}
}
@media (prefers-reduced-motion:reduce){.gh.gh-sw.gh-sw-live:has(> .gh-sw-hit:active){transform:none}}
`;function _(e,t){if(e==null||e===``)return t;if(typeof e==`boolean`||typeof e==`number`)return e;let n=typeof e==`string`?e.trim():``;return n?n===`true`?!0:n===`false`?!1:/^-?\d+([.,]\d+)?$/.test(n)?Number(n.replace(`,`,`.`)):n:t}function v(e,t){if(e==null)return!1;if(typeof t==`boolean`)return typeof e==`boolean`?e===t:r(e)===t;if(typeof t==`number`){let n=f(e);return n!==null&&n===t}return(typeof e==`string`||typeof e==`number`||typeof e==`boolean`?String(e):``).trim().toLowerCase()===String(t).trim().toLowerCase()}var y=class y extends u{constructor(e){super(e),i(this,`timers`,new Set),i(this,`optTimer`,void 0),i(this,`levelSendTimer`,void 0),i(this,`levelHoldTimer`,void 0),i(this,`confirmTimer`,void 0),i(this,`pending`,new Map),i(this,`trackRef`,t.createRef()),i(this,`yesRef`,t.createRef()),i(this,`hitRef`,t.createRef()),i(this,`dragging`,!1),i(this,`lastLevel`,null),i(this,`onActivate`,()=>{this.props.editMode||(d(this.state.rxData.confirm)&&!this.state.confirming?(this.setState({confirming:!0}),this.confirmTimer&&clearTimeout(this.confirmTimer),this.confirmTimer=setTimeout(()=>this.closeConfirm(),1e4)):this.run())}),i(this,`onCancel`,()=>this.closeConfirm()),i(this,`onConfirm`,()=>this.closeConfirm(()=>this.run())),i(this,`onKeyDown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),e.repeat||this.onActivate())}),i(this,`onPointerDown`,e=>{var t,n;if(this.props.editMode||e.button>0)return;e.stopPropagation();let r=this.levelAt(e.clientX);r!==null&&(this.dragging=!0,(t=(n=e.currentTarget).setPointerCapture)==null||t.call(n,e.pointerId),this.setState({optLevel:r}))}),i(this,`onPointerMove`,e=>{if(!this.dragging)return;let t=this.levelAt(e.clientX);t!==null&&t!==this.state.optLevel&&this.setState({optLevel:t})}),i(this,`onPointerUp`,e=>{var t,n;if(!this.dragging)return;this.dragging=!1,(t=(n=e.currentTarget).releasePointerCapture)==null||t.call(n,e.pointerId);let r=this.state.optLevel;r!==null&&this.writeLevel(r),this.setState({optLevel:r})}),i(this,`onLevelKey`,e=>{if(this.props.editMode)return;let[t,n]=this.levelRange(),r=this.level()??t,i=Math.max(1,Math.round((n-t)/20)),o=null;e.key===`ArrowRight`||e.key===`ArrowUp`?o=r+i:e.key===`ArrowLeft`||e.key===`ArrowDown`?o=r-i:e.key===`Home`?o=t:e.key===`End`?o=n:e.key===`PageUp`?o=r+i*2:e.key===`PageDown`&&(o=r-i*2),o!==null&&(e.preventDefault(),e.stopPropagation(),o=a(Math.round(o),t,n),this.setState({optLevel:o}),this.writeLevel(o,350))}),p(`switch`,g),this.state={...this.state,demoOn:!0,optOn:null,optLevel:null,flash:!1,done:!1,confirming:!1}}static getWidgetInfo(){return{id:`tplGlashausSwitch`,visSet:s,visSetLabel:`vis_2_widgets_glashaus`,visSetColor:o,visSetIcon:`widgets/${s}/img/vis-2-widgets-glashaus.svg`,visName:`Switch`,visWidgetLabel:`switch_widget`,visAttrs:[{name:`common`,fields:[{name:`oid`,label:`sw_oid`,type:`id`,tooltip:`sw_oid_tip`,onChange:async(e,t,n,r)=>{let i=t[e.name];if(!c(i)||t.title)return;let a=await r.getObject(i),o=a==null?void 0:a.common;if(!o)return;let s=o.name;t.title=typeof s==`object`?s[u.getLanguage()]||s.en:s||i.split(`.`).pop(),n(t)}},{name:`oidState`,label:`sw_oid_state`,type:`id`,tooltip:`sw_oid_state_tip`},{name:`title`,label:`title`},...u.iconFields(`bulb`),...u.accentFields(``,`sun`),{name:`type`,label:`sw_type`,type:`select`,options:[{value:`switch`,label:`sw_type_switch`},{value:`button`,label:`sw_type_button`},{value:`scene`,label:`sw_type_scene`}],default:`switch`},{name:`valueOn`,label:`sw_value_on`,default:`true`,tooltip:`sw_value_tip`},{name:`valueOff`,label:`sw_value_off`,default:`false`,tooltip:`sw_value_tip`,hidden:e=>e.type===`scene`},{name:`textOn`,label:`sw_text_on`,tooltip:`sw_text_tip`},{name:`textOff`,label:`sw_text_off`,tooltip:`sw_text_tip`},{name:`layout`,label:`sw_layout`,type:`select`,options:[{value:`tile`,label:`sw_layout_tile`},{value:`row`,label:`sw_layout_row`}],default:`tile`},{name:`spin`,label:`sw_spin`,type:`checkbox`,default:!1}]},{name:`dimmer`,label:`group_sw_dimmer`,hidden:e=>e.type===`button`||e.type===`scene`,fields:[{name:`levelOid`,label:`sw_level_oid`,type:`id`,tooltip:`sw_level_tip`},{name:`levelMin`,label:`sw_level_min`,type:`number`,default:0,hidden:e=>!c(e.levelOid)},{name:`levelMax`,label:`sw_level_max`,type:`number`,default:100,hidden:e=>!c(e.levelOid)},{name:`levelUnit`,label:`unit`,default:`%`,hidden:e=>!c(e.levelOid)}]},{name:`confirmation`,label:`group_sw_confirm`,fields:[{name:`confirm`,label:`sw_confirm`,type:`checkbox`,default:!1},{name:`confirmText`,label:`sw_confirm_text`,hidden:e=>!d(e.confirm)}]},u.designGroup()],visDefaultStyle:{width:180,height:150,position:`absolute`},visPrev:`widgets/${s}/img/prev_switch.png`}}getWidgetInfo(){return y.getWidgetInfo()}componentDidUpdate(e,t){if(super.componentDidUpdate(e,t),this.state.confirming&&!t.confirming){var n;(n=this.yesRef.current)==null||n.focus()}}componentWillUnmount(){this.timers.forEach(e=>clearTimeout(e)),this.timers.clear(),[this.optTimer,this.levelSendTimer,this.levelHoldTimer,this.confirmTimer].forEach(e=>e&&clearTimeout(e)),this.pending.forEach((e,t)=>this.ghSet(t,e)),this.pending.clear(),super.componentWillUnmount()}onStateUpdated(e,t){super.onStateUpdated(e,t);let n=this.state.rxData,r=this.readSource();this.state.optOn!==null&&(r==null?void 0:r.id)===e&&this.valueOn(r,t==null?void 0:t.val)===this.state.optOn&&this.setState({optOn:null}),this.state.optLevel!==null&&e===n.levelOid&&!this.dragging&&!this.levelSendTimer&&f(t==null?void 0:t.val)===this.state.optLevel&&this.setState({optLevel:null})}later(e,t){let n=setTimeout(()=>{this.timers.delete(n),t()},e);this.timers.add(n)}isDemo(){let e=this.state.rxData;return!c(e.oid)&&!c(e.oidState)&&!c(e.levelOid)}levelRange(){let e=this.state.rxData,t=f(e.levelMin)??0,n=f(e.levelMax)??100;return n>t?[t,n]:[0,100]}level(){if(this.state.optLevel!==null)return this.state.optLevel;let e=this.state.rxData;return c(e.levelOid)?this.ghNum(e.levelOid):null}readSource(){let e=this.state.rxData,t=(e.type||`switch`)===`switch`;return c(e.oidState)?{id:e.oidState,level:!1}:t&&c(e.oid)?{id:e.oid,level:!1}:t&&c(e.levelOid)?{id:e.levelOid,level:!0}:null}valueOn(e,t){if(t==null)return null;if(e.level){let e=f(t);return e===null?null:e>this.levelRange()[0]}let n=this.state.rxData;return v(t,_(n.valueOn,!0))?!0:!v(t,_(n.valueOff,!1))&&r(t)}isOn(){if(this.isDemo())return this.state.demoOn;if(this.state.optOn!==null)return this.state.optOn;let e=this.readSource();return e?this.valueOn(e,this.ghVal(e.id)):null}closeConfirm(e){var t;this.confirmTimer&&=(clearTimeout(this.confirmTimer),void 0);let n=!!((t=this.yesRef.current)!=null&&(t=t.parentElement)!=null&&t.contains(document.activeElement));this.setState({confirming:!1},()=>{if(n){var t;(t=this.hitRef.current)==null||t.focus()}e==null||e()})}flashTile(){this.setState({flash:!0,done:!0}),this.later(650,()=>this.setState({flash:!1})),this.later(1800,()=>this.setState({done:!1}))}run(){let e=this.state.rxData,t=e.type||`switch`,n=_(e.valueOn,!0),r=_(e.valueOff,!1);if(t!==`switch`){if(c(e.oid)&&(this.ghSet(e.oid,n),t===`button`)){let t=e.oid;this.pending.set(t,r),this.later(300,()=>{this.pending.delete(t),this.ghSet(t,r)})}this.flashTile();return}if(this.isDemo()){this.setState({demoOn:!this.state.demoOn});return}let i=!this.isOn();if(c(e.oid))this.ghSet(e.oid,i?n:r);else if(c(e.levelOid)){let[t,n]=this.levelRange(),r=this.level();r!==null&&r>t&&(this.lastLevel=r),this.ghSet(e.levelOid,i?this.lastLevel??n:t)}else return;this.setState({optOn:i}),this.optTimer&&clearTimeout(this.optTimer),this.optTimer=setTimeout(()=>this.setState({optOn:null}),4e3)}levelAt(e){let t=this.trackRef.current;if(!t)return null;let n=t.getBoundingClientRect();if(!n.width)return null;let[r,i]=this.levelRange(),o=n.height,s=a((e-n.left-o/2)/Math.max(1,n.width-o),0,1);return Math.round(r+s*(i-r))}writeLevel(e,t=0){let n=this.state.rxData.levelOid;[this.levelSendTimer,this.levelHoldTimer].forEach(e=>e&&clearTimeout(e)),this.levelSendTimer=void 0;let r=()=>{this.levelSendTimer=void 0,this.pending.delete(n),this.ghSet(n,e),this.levelHoldTimer=setTimeout(()=>{this.dragging||this.setState({optLevel:null})},4e3)};t?(this.pending.set(n,e),this.levelSendTimer=setTimeout(r,t)):r()}renderLevel(t,r){let i=this.state.rxData;if(!c(i.levelOid))return null;let[o,s]=this.levelRange(),d=this.level(),f=d===null?0:a((d-o)/(s-o),0,1),p=i.levelUnit??`%`,m=d===null?`–`:`${l(d,0,this.ghLang())}${p?` ${p}`:``}`;return e(`div`,{className:`gh-sw-lvl${this.dragging?` gh-sw-drag`:``}`,children:[n(`div`,{ref:this.trackRef,className:`gh-sw-trk`,role:`slider`,tabIndex:this.props.editMode?-1:0,"aria-label":`${r} ${u.tr(`sw_level`)}`.trim(),"aria-valuemin":o,"aria-valuemax":s,"aria-valuenow":d??o,"aria-valuetext":m,"aria-disabled":t===null||void 0,onPointerDown:this.onPointerDown,onPointerMove:this.onPointerMove,onPointerUp:this.onPointerUp,onPointerCancel:this.onPointerUp,onKeyDown:this.onLevelKey,children:n(`span`,{className:`gh-sw-fill`,style:{width:`calc(var(--gh-sw-k) + (100% - var(--gh-sw-k)) * ${f.toFixed(4)})`}})}),n(`span`,{className:`gh-sw-lv`,children:m})]})}renderWidgetBody(t){this.ghRenderStart(t);let r=this.state.rxData,i=this.ghLang(),a=this.isDemo(),o=r.type===`button`||r.type===`scene`?r.type:`switch`,s=r.layout===`row`?`row`:`tile`,f=r.title||(a?u.tr(`sw_demo_title`):``),p=this.isOn(),g=p===null&&o===`switch`,_=o===`switch`?!!p:this.state.flash||c(r.oidState)&&!!p,v=(r.accent||`sun`)===`fg`,y=v&&_?`var(--gh-bg)`:this.ghAccent(``,`sun`),b;if(o===`switch`){if(p===null)b=u.tr(`sw_no_value`);else if(p){b=r.textOn||u.tr(`sw_on`);let e=this.level();if(c(r.levelOid)&&e!==null){let t=r.levelUnit??`%`;b+=` · ${l(e,0,i)}${t?` ${t}`:``}`}}else b=r.textOff||u.tr(`sw_off`)}else b=this.state.done?r.textOn||u.tr(`sw_done`):c(r.oidState)&&p?r.textOn||u.tr(`sw_active`):r.textOff||u.tr(`sw_tap`);let x=[`gh-sw`,`gh-sw-${s}`,_?`gh-on`:``,v?`gh-sw-ink`:``,o===`switch`&&c(r.levelOid)?`gh-sw-haslvl`:``,g?`gh-sw-nodata`:``,d(r.spin)?`gh-sw-spin`:``,this.props.editMode?`gh-sw-edit`:`gh-sw-live`].filter(Boolean).join(` `),S=r.confirmText||u.tr(`sw_confirm_default`);return e(`div`,{className:this.ghClass(x),style:{"--gh-c":y},children:[e(`div`,{ref:this.hitRef,className:`gh-sw-hit`,role:o===`switch`?`switch`:`button`,"aria-checked":o===`switch`?!!p:void 0,"aria-label":`${f}: ${b}`,tabIndex:this.props.editMode?-1:0,onClick:this.onActivate,onKeyDown:this.onKeyDown,children:[n(`span`,{className:`gh-sw-ico`,children:n(m,{name:this.ghIcon(),color:y})}),n(`span`,{className:`gh-sw-tg`,children:o===`switch`?n(`span`,{className:`gh-toggle${p?` gh-sw-tog-on`:``}`}):n(`span`,{className:`gh-sw-go`,children:n(h,{name:o===`scene`?`play`:`power`})})}),e(`span`,{className:`gh-sw-txt`,children:[n(`span`,{className:`gh-sw-nm`,children:f}),n(`span`,{className:`gh-sw-st`,children:b})]})]}),o===`switch`?this.renderLevel(p,f):null,this.state.confirming?e(`div`,{className:`gh-sw-cf`,role:`alertdialog`,"aria-label":S,onClick:e=>e.stopPropagation(),onKeyDown:e=>{e.key===`Escape`&&(e.stopPropagation(),this.onCancel())},children:[n(`span`,{className:`gh-sw-q`,children:S}),e(`span`,{className:`gh-sw-btns`,children:[e(`button`,{type:`button`,className:`gh-outline`,"aria-label":u.tr(`sw_cancel`),onClick:this.onCancel,children:[n(`span`,{className:`gh-sw-cx-t`,children:u.tr(`sw_cancel`)}),n(`span`,{className:`gh-sw-cx-i`,"aria-hidden":`true`,children:`×`})]}),n(`button`,{ref:this.yesRef,type:`button`,className:`gh-ink`,onClick:this.onConfirm,children:u.tr(`sw_confirm_yes`)})]})]}):null,this.ghDemoBadge(a)]})}};export{y as default};